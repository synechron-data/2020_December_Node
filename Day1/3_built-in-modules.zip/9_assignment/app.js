const http = require('http');
const fs = require('fs');

var server = http.createServer((req, res) => {
    if (req.url != '/favicon.ico') {
        const filepath = `${__dirname}${req.url}.pdf`;

        const readStream = fs.createReadStream(filepath);
        res.setHeader("content-type", "application/pdf");

        // readStream.on('data', (chunk) => {
        //     res.write(chunk);
        // });

        // readStream.on('end', () => {
        //     res.end();
        // });

        readStream.pipe(res);

        readStream.on('error', (err) => {
            res.setHeader("content-type", "text");
            res.end("Error Loading File");
        })
    }
});

server.listen(3000);

function onError(err) {
    console.log(err);
}

function onListening() {
    var address = server.address();
    console.log("Server started on port: ", address.port);
}

server.on('error', onError);
server.on('listening', onListening);