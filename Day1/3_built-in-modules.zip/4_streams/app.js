// const fs = require('fs');

// var readStream = fs.createReadStream('./file1.txt');
// let fData = "";

// readStream.on('open', () => {
//     console.log("File Opened.....");
// });

// readStream.on('error', (err) => {
//     console.log(err);
// });

// // Chunk Size - 64 * 1024

// readStream.on('data', (chunk) => {
//     // console.log(chunk);
//     fData += chunk;
// });

// readStream.on('end', (err) => {
//     console.log("File End.....");
//     console.log(fData);
// });

// ------------------------------------------------------

const fs = require('fs');

var readStream = fs.createReadStream('./file1.txt');
var writeStream = fs.createWriteStream('./file2.txt');

readStream.on('data', (c) => {
    writeStream.write(c);
});

readStream.on('end', (err) => {
    console.log("File Copied.....");
    readStream.close();
    writeStream.close();
});