// Every action which you perform on your computer system is an event

const StringEmitter = require('./StringEmitter');
const sEmitter = new StringEmitter();

// var s = sEmitter.getString();
// console.log(s);

// setInterval(() => {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// sEmitter.pushString((s) => {
//     console.log(s);
// });

sEmitter.on('data', (s) => {
    console.log("S1 - ", s);
});

let count = 0;
function S2(s) {
    ++count;
    console.log("S2 - ", s.toUpperCase());
    if (count > 2) {
        sEmitter.removeListener('data', S2);
    }
}

sEmitter.on('data', S2);
