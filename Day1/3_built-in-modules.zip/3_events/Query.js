var events = require('events');
var eEmitter = new events.EventEmitter();

function listener() {
    console.log("Listener Executed.....");
}

eEmitter.addListener('test', listener);

eEmitter.emit('test');