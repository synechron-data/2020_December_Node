const fs = require('fs');

fs.watch('./my-folder', (eventType, filename) => {
    console.log(`File - ${filename}, ${eventType}d at: ${new Date().toLocaleTimeString()}`);
});

console.log("Folder Watcher started....");