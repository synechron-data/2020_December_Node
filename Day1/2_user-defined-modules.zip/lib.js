console.log("Lib Module Loaded...");
// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

// var fname = "Manish";
// var lname = "Sharma";
// module.exports = { firstname: fname, lastname: lname };

// Named Exports
// var fname = "Manish";
// var lname = "Sharma";

// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function(message){
//     return `From Lib - ${message}`;
// }

// module.exports.Employee = (function () {
//     function Employee(name) {
//         this._name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this._name;
//     }

//     Employee.prototype.setName = function (value) {
//         this._name = value;
//     }

//     return Employee;
// })();

// -------------------------------------

var fname = "Manish";
var lname = "Sharma";

exports.firstname = fname;
exports.lastname = lname;

exports.log = function(message){
    return `From Lib - ${message}`;
}

// exports.Employee = (function () {
//     function Employee(name) {
//         this._name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this._name;
//     }

//     Employee.prototype.setName = function (value) {
//         this._name = value;
//     }

//     return Employee;
// })();

// function Employee(name) {
//     this._name = name;
//     var age = 20;
// }

// var e = new Employee("Manish");
// console.log(e._name);
// console.log(e.age);

class Employee {
    constructor(name){
        this._name = name;
    }

    setName(value){
        this._name = value;
    }

    getName(){
        return this._name;
    }
}

exports.Employee = Employee;