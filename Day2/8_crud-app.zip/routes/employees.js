const express = require('express');
const router = express.Router();

const employeeCtrl = require('../controllers/employee-controller');

router.get("/", employeeCtrl.index);

router.get("/details/:empid", employeeCtrl.details);

router.get("/create", employeeCtrl.create_get);

router.post("/create", employeeCtrl.create_post);

router.get("/edit/:empid", employeeCtrl.edit_get);

router.post("/edit/:empid", employeeCtrl.edit_post);

router.get("/delete/:empid", employeeCtrl.delete_get);

router.post("/delete/:empid", employeeCtrl.delete_post);

module.exports = router;