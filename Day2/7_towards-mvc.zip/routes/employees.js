const express = require('express');
const router = express.Router();

const employeeCtrl = require('../controllers/employee-controller');

router.get("/", employeeCtrl.index);

router.get("/details/:empid", employeeCtrl.details);

module.exports = router;