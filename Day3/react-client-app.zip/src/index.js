import React from 'react';
import ReactDOM from 'react-dom';

import RootComponent from './components/root/RootComponent';


ReactDOM.render(
  <React.StrictMode>
    <RootComponent />
  </React.StrictMode>,
  document.getElementById('root')
);
